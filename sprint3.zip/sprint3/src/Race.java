import java.util.ArrayList;

public class Race{
	String racetype = "IND";
	int runNumber = 1;
	
	ArrayList<Racer> racers;
	
	Time start;
	Time finish;
	
	public Race(){
		racers = new ArrayList<Racer>();
	}
	public Race(ArrayList<Racer> racers) {
		this.racers = racers;
	}
	public void setRaceType(String type){
		switch(type) {
		case "IND":
			racetype = type;
		case "PARIND":
			racetype = type;
		case "GRP":
			racetype = type;
//		case "PARGRP":
//			racetype = type;
			
		}
	}
	public void addRacer(Racer racer){
		racers.add(racer);
	}
	public Racer getRacer(int num){
		for(int i = 0; i < racers.size(); ++i) {
			if (racers.get(i).getNum() == num){
				return racers.get(i);
			}
		}
		return null;
	}
	public void setStart(String time){
		start = new Time(time);
	}
	public void setFinish(String time) {
		finish = new Time(time);
	}
	
}
