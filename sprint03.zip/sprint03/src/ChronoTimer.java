import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class ChronoTimer {
	boolean power = false;
	
	Time endTime;
	Race r1 = new Race();
	ArrayList<Racer> queued = new ArrayList<Racer>();
	ArrayList<Racer> running = new ArrayList<Racer>();
	ArrayList<Racer> finished = new ArrayList<Racer>();
	
	int runs = 0;
	
	Channel c1 = new Channel(1);
	Channel c2 = new Channel(2);
	
	public ChronoTimer() {
		
	}
	
	public void setRace(Race r){
		r1 = r;
	}
	
	public void setRace(String gsonIN){
		Gson g = new Gson();
		ArrayList<Racer> racer = (g.fromJson(gsonIN,new TypeToken<Collection<Racer>>(){}.getType()));
		Race r = new Race(racer);
		setRace(r);
	}
	
	public void setEvent(String event) {
		r1.setRaceType(event);
	}
	
	public void printConsole(String input) {
		System.out.println("console: " + input);
	}
	
	public boolean power(){
		power = !power;
		if (power) {
			printConsole("System is on.");
		}
		else {
			printConsole("System is off.");
		}
		return power;
	}
	
	public void connectChannel(int channel, String sensor) {
		if (channel == 1 || channel == 4) c1.connect(sensor);
		else if (channel == 2 || channel == 4) c2.connect(sensor);
		printConsole("channel " + channel + " is now connected to " + sensor);
	}
	
	public void toggle(int n){
		if (n == 1 || n == 4) c1.toggle();
		else if (n == 2 || n == 4) c2.toggle();
		printConsole("channel " + n + " is ready to record time.");
	}
	
	public void setRunner(int num) {//adds runner to racequeue based off their number
		if(r1.getRacer(num) != null) {
			queued.add(r1.getRacer(num));
		}
		else {
			Racer r = new Racer(num, "Unnamed");
			r1.addRacer(r);
			queued.add(r);
			
		}
		printConsole("Racer " + num + " has been added to queue.");
	}
	
	public boolean clear(int num) {
		Racer temp = r1.getRacer(num);
		if(temp != null) {
			queued.remove(temp);
			return true;
		}
		return false;
	}
	
	
	public void trigger(int channel, String time) {
		
		if (channel == 1 || channel == 3) {
			if (!c1.enable) {
				printConsole("Channel" + channel + " is not active");
			}
			if (!queued.isEmpty()) {
				
					Racer racer = queued.remove(0);
					running.add(racer);
					racer.setStart(time);
					printConsole("Racer " + racer.num + " starts running at time " + time);
					if(r1.racetype.equals("GRP") && !queued.isEmpty()) {
						trigger(channel,time);
					}
				
				
			}
			else {
				printConsole("There are no racers queued to start.");
			}
		}
		else if (channel == 2 || channel == 4) {
			if (!c2.enable) {
				printConsole("Channel 4 is not active");
			}
			if (!running.isEmpty()) {
				if(r1.racetype.equals("IND")) {
					Racer racer = running.remove(0);
					finished.add(0,racer);
					racer.finished(time);
					printConsole("Racer " + racer.num + " finishes running at time " + time);
				}
				
			}
			else {
				printConsole("There are no racers currently running.");
			}
		}
		else {
			printConsole("Only channels 1, 2, 3 and 4 are being used.");
		}
	}
	
	public void groupTrigger(int channel, String time, String rNum){
		int num = Integer.parseInt(rNum);
		Racer racer = r1.getRacer(num);
		if (racer!=null && running.contains(racer)){
			running.remove(racer);
			finished.add(0,racer);
			racer.finished(time);
			printConsole("Racer " + racer.num + " finishes running at time " + time);
		}
		else {
			printConsole("Invalid racer number entered!");
		}
	}
	
	public void cancel(){
		queued.add(0, running.remove(0));
	}

	public void print() {
		++runs;
		System.out.println("-----FINAL RESULTS-----");
		for (Racer racer : finished) {
			System.out.println("Racer " + racer.num + " " + racer.finishTime());
		}
		try (Writer w = new FileWriter("RUN" + runs +".txt")){
   		 System.out.println("exiting");
			 Gson gson = new GsonBuilder().create();
			 gson.toJson(r1,w);
		 } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void dnf() {
		for(Racer racer : running){
			finished.add(racer);
		}
	}

	public void endRun() {
		queued.clear();
		running.clear();
		finished.clear();
		
	}
	
}